

#include<stdio.h>
FILE *f_open(char *file_name,char *arr);
int f_close(FILE *); 
int f_write(void *,size_t ,size_t ,FILE *);

