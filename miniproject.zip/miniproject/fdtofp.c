#include "fdtofp.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


/*int main(int argc,char *argv[]){
 int fd;
 FILE *fp;
 fd = open(argv[1],O_WRONLY | O_CREAT | O_TRUNC);
  if(fd<0){
    printf("open call fail");
    return -1;
 }
 fp=fdopen(fd,"w");
 fprintf(fp,"we got file pointer fp by using File descriptor fd");
 fclose(fp);	
 return 0;
}*/

FILE *f_open(char *file_name,char *arr)
{
	int fd;
	
	fd = open(file_name,O_WRONLY| O_CREAT, S_IRUSR | S_IWUSR);
	if(fd<0)
	{
		printf("open call fail");
    		return NULL;
    	} 
    	//fq =
    	return fdopen(fd,"w");
}
int f_close(FILE *p)
{
	
    return 	close (fileno(p));

}
int f_write(void *input_file,size_t size,size_t nmemb,FILE *p)
{
	int fd;
	fd=fileno(p);
	
	return write(fd,input_file,nmemb);
}

























